<footer>
    <div class="footer">
        <p>&copy; <?php itzuli("footer") ?> </p>
    </div>
</footer>
</body>