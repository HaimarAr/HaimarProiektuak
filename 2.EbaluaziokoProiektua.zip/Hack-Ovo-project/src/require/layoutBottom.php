<footer>
    <?php require_once("../../require/footer.php"); ?>
</footer>
</body>

</html>